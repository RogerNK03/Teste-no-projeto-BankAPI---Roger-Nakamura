package br.edu.utfpr.bankapi.validations;

public class AvaliableBalanceValiadationTest {
}